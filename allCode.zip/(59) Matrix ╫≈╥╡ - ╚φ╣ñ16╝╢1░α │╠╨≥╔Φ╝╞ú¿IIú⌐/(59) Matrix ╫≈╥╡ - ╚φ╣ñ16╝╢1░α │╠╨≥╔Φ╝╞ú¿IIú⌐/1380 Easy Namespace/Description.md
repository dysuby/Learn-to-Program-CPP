# Easy Namespace

### Let's finish a simple task.
### Your task is to create a function :  void Handle();
### It could satisfy the following request:
* For the inflag in mfc, inflag++;
* For the inflag in owl, inflag--;
* For the global inflag, inflag mod 100;
#### It's easy, but I hope you could understand why we use namespace.
 