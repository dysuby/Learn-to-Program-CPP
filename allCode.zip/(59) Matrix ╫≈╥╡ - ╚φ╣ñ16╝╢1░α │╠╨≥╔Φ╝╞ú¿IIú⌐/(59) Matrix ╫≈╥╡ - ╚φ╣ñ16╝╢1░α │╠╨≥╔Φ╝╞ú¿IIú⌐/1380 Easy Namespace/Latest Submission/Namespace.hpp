#ifndef Namespace
#define Namespace

int inflag;

namespace mfc {
  int inflag;
}

namespace owl {
  int inflag;
}
void Handle();
#endif