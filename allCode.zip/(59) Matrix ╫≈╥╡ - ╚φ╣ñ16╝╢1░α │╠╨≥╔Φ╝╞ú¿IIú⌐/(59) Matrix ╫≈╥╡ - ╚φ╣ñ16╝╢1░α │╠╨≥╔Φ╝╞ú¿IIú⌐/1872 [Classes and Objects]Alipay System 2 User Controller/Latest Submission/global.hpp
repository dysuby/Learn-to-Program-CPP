#ifndef ALIPAY_GLOBAL_H_
#define ALIPAY_GLOBAL_H_
 
namespace Alipay {
#define boss "Mayun"
#define MAX_USER 10000
enum GENDER { MALE = 0, FEMALE = 1 };
 
const double PRECISION = 0.000001;
}
 
#endif  // !ALIPAY_GLOBAL_H_
 