# [Operator Overloading]Big Integer Add & Subtract

This is an easy big integer. Your task is to finish the class big integer:

 

## Tips:

* size_ means the size of  the big integer

* friend function should have been declared outside;

* when you declare the friend function, you should forward declare the class.

* when you cannot compile, try to read the informations or google it.

* overload "<<" : please output like this format: "123456", no wrap.

* overload "-": we promise that a > b when a - b .

## Hint
operator overloading ( we promise that left will bigger than right when doing subtract operation )

friend function

deep copy

*From: 欧文杰*
