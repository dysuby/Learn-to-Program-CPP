# [Inheritance]Inheritance

## Task
Finish header file of the Inheritance class.  
## Hints
1\. All function is finished.  
2\. You need write inheritance relation between 5 class so that it can print
right message.       
## A Sample
### Input
```
6590

```
### Output
```
test token: 6590

creat base A
base A

creat base B
base B

creat derived A
base A
derived A

creat derived B
base A
base B
derived B

creat C
base A
derived A
base A
base B
derived B
C

destructor
~ C
~ derived B
~ base B
~ base A
~ derived A
~ base A
~ derived B
~ base B
~ base A
~ derived A
~ base A
~ base B
~ base A

```
*出题人： 李天培*