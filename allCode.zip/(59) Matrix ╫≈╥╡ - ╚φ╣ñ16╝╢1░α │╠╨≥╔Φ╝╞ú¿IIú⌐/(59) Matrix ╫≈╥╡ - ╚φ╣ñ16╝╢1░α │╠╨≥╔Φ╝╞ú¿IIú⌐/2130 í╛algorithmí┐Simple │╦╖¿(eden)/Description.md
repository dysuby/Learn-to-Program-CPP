# 【algorithm】Simple 乘法(eden)

## Descrption
In a famous web game, players are able to command their fleets and fight with
enemies.

The enemies own a very powerful battleship -- the Re Class. She is so powerful
that she is able to beat the player's whole fleet by herself.

Now you know that a Re Class battleship is able to attack N times in a battle.
And you have to cost M tons of steel to repair the damage caused by each
attack.

So how many tons of steel do you need to fight with a Re Class ?

0 < N, M < 101001, both N and M are integers.



Sample Input

12450

66666



Sample Output

829991700

## Discussion
Discussion is not available for this exercise.

## Hint
高精度乘法

From: 彭勃