#include "user.hpp"
#include "test.hpp"
 
int main() {
  unittest::TEST t;
  t.runAllCases();
  return 0;
}
 