# [Operator Overloading]Simulate std::string

Implement the class String with given header, you can also make it like std::string!

member function 'compare()' returns -1 for <, 0 for ==, 1 for >.

Any question see STL references.

*From: 范子垚*