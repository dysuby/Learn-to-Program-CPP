# [Operator Overloading]Set Operations

### You need finish function.

## Require knowledge:
1. Know set operations：include 

   * intersection(交集）

   * union（并集）

   * the complement of B with respect to A（B对A的补）

   * symmetric difference（对称差）

2. copy constructor

3. overload

## Require task:

1. Define a copy constructor

2. Overload four operators

## Hint

*SourceAuthor： 李天培*