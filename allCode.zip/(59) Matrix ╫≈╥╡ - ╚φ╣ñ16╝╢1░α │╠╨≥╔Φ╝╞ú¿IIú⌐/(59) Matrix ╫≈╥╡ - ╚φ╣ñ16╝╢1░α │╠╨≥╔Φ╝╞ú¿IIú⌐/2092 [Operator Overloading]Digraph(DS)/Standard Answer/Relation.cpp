//
//  Relation.cpp
//  C++
//
//  Created by 李天培 on 16/4/9.
//  Copyright © 2016年 lee. All rights reserved.
//

#include "Relation.hpp"

Relation::Relation(BooleanMatrix const & m): matrix(m) {
}

