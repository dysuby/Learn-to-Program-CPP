# [Classes and Objects]Set

#### A set is any well-defined collection of objects called the elements or members of the set.

### Required Tasks:

#### 1. Finish Set.cpp. Its header file is Set.hpp.

#### (1) Defines two constructors. One without parameters, Another has two parameter, mean initial set with a array and its size.

#### (2) Defines five function. All description is in Set.hpp.
### Hint
#### 集合中成员不重复。不需要考虑集合中成员的顺序。
*From 李天培*