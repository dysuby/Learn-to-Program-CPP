# [STL]String & Cstring

## Task

* Implement the two functions which proceed to exchange between string and cstring.
 
(1) `std::string change1(const char* cstr);`  

    Convert a string of the cstring type to one belonging to the string type.

(2) `void change2(std::string str, char* cstr);`  

    Convert a string of the string type to one belonging to the cstring type.

**From：** 黄嘉敏(TA)
