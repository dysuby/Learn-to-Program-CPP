# [Algorithm]Operations on Relations

请复习《离散数学》相关知识。   
*出题人：李天培*