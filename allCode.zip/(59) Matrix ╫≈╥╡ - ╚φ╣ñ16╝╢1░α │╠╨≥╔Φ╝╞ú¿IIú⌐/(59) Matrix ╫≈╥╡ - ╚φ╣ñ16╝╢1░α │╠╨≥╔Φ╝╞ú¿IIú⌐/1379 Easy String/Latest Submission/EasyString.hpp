#ifndef EasyStr
#define EasyStr
#include <iostream>
using std::cin;
using std::string;
void Assign(char * &, int);
void AddTwo(string &, char * &, char * &);
#endif